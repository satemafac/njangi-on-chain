"use strict";(()=>{var e={};e.id=464,e.ids=[464],e.modules={5600:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},9021:e=>{e.exports=require("fs")},6762:(e,r)=>{Object.defineProperty(r,"M",{enumerable:!0,get:function(){return function e(r,t){return t in r?r[t]:"then"in r&&"function"==typeof r.then?r.then(r=>e(r,t)):"function"==typeof r&&"default"===t?r:void 0}}})},6722:(e,r,t)=>{t.r(r),t.d(r,{config:()=>o,default:()=>d,routeModule:()=>l});var s={};t.r(s),t.d(s,{default:()=>c});var n=t(9947),u=t(2706),i=t(6762),a=t(7404);async function c(e,r){if("GET"!==e.method)return r.status(405).json({success:!1,message:"Method not allowed"});try{let{circleId:t}=e.query;if(!t||"string"!=typeof t)return r.status(400).json({success:!1,message:"Missing or invalid circleId parameter"});let s=a.A.getPendingRequestsByCircleId(t);return r.status(200).json({success:!0,data:s})}catch(e){return console.error("API error getting pending requests:",e),r.status(500).json({success:!1,message:"Internal server error"})}}let d=(0,i.M)(s,"default"),o=(0,i.M)(s,"config"),l=new n.PagesAPIRouteModule({definition:{kind:u.A.PAGES_API,page:"/api/join-requests/[circleId]",pathname:"/api/join-requests/[circleId]",bundlePath:"",filename:""},userland:s})},7404:(e,r,t)=>{t.d(r,{A:()=>l});let s=require("better-sqlite3");var n=t.n(s),u=t(9021),i=t.n(u);let a=require("path");var c=t.n(a);let d=c().join(process.cwd(),"join-requests.db");class o{constructor(){let e=c().dirname(d);i().existsSync(e)||i().mkdirSync(e,{recursive:!0}),this.db=new(n())(d),this.initializeDatabase()}initializeDatabase(){this.db.pragma("journal_mode = WAL");let e=`
      CREATE TABLE IF NOT EXISTS join_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        circleId TEXT NOT NULL,
        circleName TEXT NOT NULL,
        userAddress TEXT NOT NULL,
        userName TEXT NOT NULL,
        requestDate INTEGER NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('pending', 'approved', 'rejected')),
        UNIQUE(circleId, userAddress)
      )
    `;this.db.exec(e),this.db.exec("CREATE INDEX IF NOT EXISTS idx_join_requests_circle_id ON join_requests(circleId)"),this.db.exec("CREATE INDEX IF NOT EXISTS idx_join_requests_status ON join_requests(status)")}createJoinRequest(e){try{let r=this.db.prepare(`
        INSERT INTO join_requests (circleId, circleName, userAddress, userName, requestDate, status)
        VALUES (@circleId, @circleName, @userAddress, @userName, @requestDate, @status)
        ON CONFLICT(circleId, userAddress) 
        DO UPDATE SET status = @status, requestDate = @requestDate
      `).run({circleId:e.circleId,circleName:e.circleName,userAddress:e.userAddress,userName:e.userName,requestDate:e.requestDate,status:e.status});if(r.changes>0)return{...e,id:r.lastInsertRowid};return null}catch(e){return console.error("Error creating join request:",e),null}}getPendingRequestsByCircleId(e){try{return this.db.prepare(`
        SELECT * FROM join_requests
        WHERE circleId = ? AND status = 'pending'
        ORDER BY requestDate DESC
      `).all(e)}catch(e){return console.error("Error getting pending requests:",e),[]}}userHasPendingRequest(e,r){try{return this.db.prepare(`
        SELECT COUNT(*) as count FROM join_requests
        WHERE circleId = ? AND userAddress = ? AND status = 'pending'
      `).get(e,r).count>0}catch(e){return console.error("Error checking pending request:",e),!1}}updateJoinRequestStatus(e,r,t){try{return this.db.prepare(`
        UPDATE join_requests
        SET status = ?
        WHERE circleId = ? AND userAddress = ? AND status = 'pending'
      `).run(t,e,r).changes>0}catch(e){return console.error("Error updating join request status:",e),!1}}getRequestsByUserAddress(e){try{return this.db.prepare(`
        SELECT * FROM join_requests
        WHERE userAddress = ?
        ORDER BY requestDate DESC
      `).all(e)}catch(e){return console.error("Error getting user requests:",e),[]}}}let l=new o},2706:(e,r)=>{Object.defineProperty(r,"A",{enumerable:!0,get:function(){return t}});var t=function(e){return e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE",e.IMAGE="IMAGE",e}({})},9947:(e,r,t)=>{e.exports=t(5600)}};var r=require("../../../webpack-api-runtime.js");r.C(e);var t=r(r.s=6722);module.exports=t})();